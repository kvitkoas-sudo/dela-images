#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Заготовка для работы с задачами проекта «Мои дела» напрямую в GitHub-CSV.
Репозиторий:  kvitkoas-sudo/dela-images
Данные:       data/dela_notion.csv (задачи), data/Resursy.csv (ресурсы)
Страница:     index.html  ->  https://kvitkoas-sudo.github.io/dela-images/

ВНИМАНИЕ: токен сюда НЕ вшит. Подставить GH_TOKEN из файла-токена проекта
(в проекте claude.ai лежит как «токен github viktoria.txt»).

Типовые операции ниже: чтение, правка задачи, добавление задачи, заливка,
публикация index.html. Кодировка CSV — utf-8-sig, перевод строк CRLF.
"""
import csv, io, base64, json, urllib.request, urllib.error

GH_TOKEN = ""  # <-- подставить перед запуском
REPO = "kvitkoas-sudo/dela-images"
CSV_PATH = "data/dela_notion.csv"
RES_PATH = "data/Resursy.csv"
INDEX_PATH = "index.html"

FIELDNAMES = ["Задача","Категория","Статус","Месяц","Приоритет","Комментарий",
              "Сумма","Трудоёмкость, ч.","Дедлайн","Старт","Финиш","Фото"]
STATUS = ["Не выполнено","Выполнено","Отменено"]  # допустимые статусы

def _api(path):
    return f"https://api.github.com/repos/{REPO}/contents/{path}"

def _hdr():
    return {"Authorization": f"Bearer {GH_TOKEN}",
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json"}

def get_file(path):
    """Возвращает (text, sha) файла из репозитория."""
    req = urllib.request.Request(_api(path) + "?ref=main", headers=_hdr())
    meta = json.load(urllib.request.urlopen(req))
    return base64.b64decode(meta["content"]).decode("utf-8"), meta["sha"]

def put_file(path, text, sha, message):
    """Заливает text в path (перезапись по sha)."""
    body = {"message": message,
            "content": base64.b64encode(text.encode("utf-8")).decode(),
            "sha": sha}
    req = urllib.request.Request(_api(path), data=json.dumps(body).encode(),
                                 method="PUT", headers=_hdr())
    return json.load(urllib.request.urlopen(req))

def read_tasks():
    """Список задач (dict) + sha CSV."""
    text, sha = get_file(CSV_PATH)
    rows = list(csv.DictReader(io.StringIO(text.lstrip("\ufeff"))))
    return rows, sha

def write_tasks(rows, sha, message):
    """Сериализует задачи обратно в CSV (utf-8-sig, CRLF) и заливает."""
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=FIELDNAMES, lineterminator="\r\n")
    w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k, "") for k in FIELDNAMES})
    data = "\ufeff" + buf.getvalue()
    return put_file(CSV_PATH, data, sha, message)

def publish_index(local_html_path, message="publish latest"):
    """Публикует локальный dela.html как index.html (GitHub Pages)."""
    _, sha = get_file(INDEX_PATH)
    text = open(local_html_path, "r", encoding="utf-8").read()
    return put_file(INDEX_PATH, text, sha, message)

def new_task(**kwargs):
    """Пустая строка задачи со всеми колонками; переопредели нужные поля."""
    r = {k: "" for k in FIELDNAMES}
    r.update(kwargs)
    return r

# ---- Пример использования ----
if __name__ == "__main__":
    # rows, sha = read_tasks()
    # for r in rows:
    #     if r["Задача"].strip() == "Купить очки":
    #         r["Статус"] = "Выполнено"; r["Сумма"] = "-6400"
    # write_tasks(rows, sha, "очки куплены")
    #
    # rows, sha = read_tasks()
    # rows.append(new_task(**{"Задача":"Новая задача","Категория":"Прочее",
    #     "Статус":"Не выполнено","Месяц":"Сентябрь 26","Приоритет":"Средний",
    #     "Сумма":"-1000","Трудоёмкость, ч.":"1","Старт":"2026-09-10","Финиш":"2026-09-10"}))
    # write_tasks(rows, sha, "добавлена задача")
    print("Заготовка. Подставь GH_TOKEN и используй функции read_tasks/write_tasks/publish_index.")
